import torch
import torch.nn as nn
import dgl
import numpy as np
import pickle
from torch.utils.data import DataLoader, Dataset, SubsetRandomSampler
from dgl.nn import EGATConv
from dgl.nn.pytorch.glob import MaxPooling
from sklearn.metrics import accuracy_score, recall_score, f1_score, precision_score, roc_auc_score, matthews_corrcoef
from sklearn.model_selection import KFold

device = torch.device('cuda:0')

def default_loader(node_feature_path, edge_feature_path, ring_angle_feature_path, ring_dist_feature_path, ca_dist_feature_path,
                    hyd_cha_feature_path, coev_feature_path, pid):
    edge_feature_data = np.load(edge_feature_path + pid + '.npz')
    contact_map = edge_feature_data['contact']
    angle_map = edge_feature_data['angle']
    node_feature_data = np.load(node_feature_path + pid + '.npz')
    node_feature = torch.tensor(node_feature_data['feature'].astype(np.float32))
    ring_angle_feature_data = np.load(ring_angle_feature_path + pid + '.npz')
    ring_angle_map = ring_angle_feature_data['ring_angle']
    ring_dist_feature_data = np.load(ring_dist_feature_path + pid + '.npz')
    ring_dist_map = ring_dist_feature_data['ring_dist']
    ca_dist_feature_data = np.load(ca_dist_feature_path + pid + '.npz')
    ca_dist_map = ca_dist_feature_data['ca_dist']
    hyd_cha_feature_data = np.load(hyd_cha_feature_path + pid + '.npz')
    hyd_map = hyd_cha_feature_data['hyd']
    cha_map = hyd_cha_feature_data['cha']
    coev_feature_data = np.load(coev_feature_path + pid + '.npz')
    coev_map = coev_feature_data['coev']
    adj = contact_map > 0
    u, v = torch.nonzero(torch.from_numpy(adj), as_tuple=True)
    num_nodes = contact_map.shape[0]
    graph1 = dgl.graph((u, v), num_nodes=num_nodes)

    graph1.ndata['feat'] = node_feature

    efeat = []
    for i in range(len(u)):
        efeat.append([contact_map[u[i], v[i]], angle_map[u[i], v[i]],
                        ring_angle_map[u[i], v[i]], ring_dist_map[u[i], v[i]],
                        ca_dist_map[u[i], v[i]], hyd_map[u[i], v[i]], cha_map[u[i], v[i]], coev_map[u[i], v[i]]])
    edge_feats = torch.as_tensor(efeat, dtype=torch.float32)
    graph1.edata['feat'] = edge_feats

    degrees = graph1.in_degrees() + graph1.out_degrees()
    if torch.nonzero(degrees > 0, as_tuple=True)[0].numel() == 0:
        return None
    graph1 = graph1.subgraph(torch.nonzero(degrees > 0, as_tuple=True)[0])

    graph1 = dgl.add_self_loop(graph1)
    graph = graph1

    return graph

coev_feature_path = ''
node_feature_path = ''
edge_feature_path = ''
ring_angle_feature_path = ''
ring_dist_feature_path = ''
ca_dist_feature_path = ''
hyd_cha_feature_path = ''

class MyDataset(Dataset):
    def __init__(self, loader=default_loader):
        super(MyDataset, self).__init__()
        self.loader = loader

        pns = []
        with open('positive_dataset.txt') as fh:
            for line in fh:
                line = line.split()
                pns.append((line[0], line[1], int(line[2])))
        with open('negative_dataset.txt') as fn:
            for line in fn:
                line = line.split()
                pns.append((line[0], line[1], int(line[2])))
        self.pns = pns

    def __getitem__(self, index):
        p1, p2, label = self.pns[index]

        G1 = self.loader(node_feature_path, edge_feature_path, ring_angle_feature_path, ring_dist_feature_path,
                         ca_dist_feature_path, hyd_cha_feature_path, coev_feature_path, p1)
        G2 = self.loader(node_feature_path, edge_feature_path, ring_angle_feature_path, ring_dist_feature_path,
                         ca_dist_feature_path, hyd_cha_feature_path, coev_feature_path, p2)
        
        if G1 is None or G2 is None:
            return None, None, None

        return G1, G2, label

    def __len__(self):
        return len(self.pns)

class EGATBlock(torch.nn.Module):
    def __init__(self,
                 in_node_feats,
                 in_edge_feats,
                 out_node_feats,
                 out_edge_feats,
                 num_heads):
        super(EGATBlock, self).__init__()

        self.in_node_feats = in_node_feats
        self.in_edge_feats = in_edge_feats
        self.out_node_feats = out_node_feats
        self.out_edge_feats = out_edge_feats
        self.num_heads = num_heads

        self.egat_1 = EGATConv(in_node_feats=self.in_node_feats,
                               in_edge_feats=self.in_edge_feats,
                               out_node_feats=self.out_node_feats,
                               out_edge_feats=self.out_edge_feats,
                               bias=True,
                               num_heads=self.num_heads)

    def forward(self, g, node_feats, edge_feats):
        new_node_feats, new_edge_feats = self.egat_1(g, node_feats, edge_feats)
        return new_node_feats, new_edge_feats

class EGATPPI(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.elu = torch.nn.ELU()

        self.mono_pro_1 = EGATBlock(in_node_feats=15, in_edge_feats=8, out_node_feats=40, out_edge_feats=16,
                                    num_heads=3)
        self.mono_pro_2 = EGATBlock(in_node_feats=120, in_edge_feats=48, out_node_feats=120, out_edge_feats=48,
                                    num_heads=1)
        self.max_pooling = MaxPooling()

        self.dropout = nn.Dropout(0.3)
        self.fc1 = nn.Linear(240, 128)
        self.fc2 = nn.Linear(128, 64)
        self.fc3 = nn.Linear(64, 1)

    def process_protein_graph(self, G):
        feats, edge_feats = self.mono_pro_1(G, G.ndata['feat'], G.edata['feat'])
        feats = feats.view(-1, 120)
        feats = self.elu(feats)
        feats, _ = self.mono_pro_2(G, feats, edge_feats.view(-1, 48))
        feats = feats.view(-1, 120)
        G.ndata['final_node_representation'] = self.elu(feats)
        return self.max_pooling(G, G.ndata['final_node_representation'])

    def forward(self, G1, G2):
        G1, G2 = G1.to(device), G2.to(device)

        g1_vec = self.process_protein_graph(G1)
        g2_vec = self.process_protein_graph(G2)
        gnn_fused = torch.cat([torch.abs(g1_vec - g2_vec), torch.mul(g1_vec, g2_vec)], dim=1)

        final_fused_vector = gnn_fused

        gc = self.dropout(final_fused_vector)
        gc = self.fc1(gc)
        gc = self.elu(gc)
        gc = self.dropout(gc)
        gc = self.fc2(gc)
        gc = self.elu(gc)
        gc = self.fc3(gc)
        out = torch.sigmoid(gc)
        return out

def collate(samples):
    samples = [s for s in samples if s[0] is not None and s[1] is not None]
    if not samples:
        return None, None, None

    graphs1, graphs2, labels = map(list, zip(*samples))

    batched_graph1 = dgl.batch(graphs1)
    batched_graph2 = dgl.batch(graphs2)
    
    return batched_graph1, batched_graph2, torch.tensor(labels)

def train_epoch(model, train_loader, loss_fn, optimizer):
    train_loss = 0
    true = []
    pred = []
    y_score = []
    model.train()
    
    accumulation_steps = 8
    
    optimizer.zero_grad() 
    
    for i, (X1, X2, label) in enumerate(train_loader):
        if X1 is None:
            continue

        label = label.to(torch.float32)
        label = label.to(device)
        
        y_pred = model(X1, X2).squeeze(1)
        y_pred = y_pred.to(torch.float32)

        loss = loss_fn(y_pred, label)
        loss = loss / accumulation_steps
        
        loss.backward()

        if (i + 1) % accumulation_steps == 0:
            optimizer.step()
            optimizer.zero_grad()

        y_score.extend(y_pred.detach())
        
        train_loss += loss.item() * accumulation_steps 

        predict = torch.where(y_pred.detach() > 0.5, torch.ones_like(y_pred), torch.zeros_like(y_pred))
        true.extend(label.detach())
        pred.extend(predict)

    true = np.array(torch.tensor(true, device='cpu'))
    pred = np.array(torch.tensor(pred, device='cpu'))
    y_score = np.array(torch.tensor(y_score, device='cpu', requires_grad=False))
    
    if len(true) == 0:
        return 0, 0, 0, 0, 0, 0, 0
    
    acc = accuracy_score(true, pred)
    recall_scores = recall_score(true, pred)
    f1_scores = f1_score(true, pred)
    precision_scores = precision_score(true, pred)
    mcc = matthews_corrcoef(true, pred)
    auc = roc_auc_score(true, y_score)
    
    return acc, train_loss, recall_scores, f1_scores, precision_scores, auc, mcc

def Val_epoch(model, test_loader, loss_fn):
    true = []
    pred = []
    y_score = []
    test_loss = 0
    model.eval()
    for i, (X1, X2, label) in enumerate(test_loader):
        if X1 is None:
            continue
            
        label = label.to(torch.float32)
        label = label.to(device)
        with torch.no_grad():
            y_pred = model(X1, X2).squeeze(1)
        y_pred = y_pred.to(torch.float32)
        y_score.extend(y_pred)
        loss = loss_fn(y_pred, label)

        test_loss += loss.item()
        predict = torch.where(y_pred > 0.5, torch.ones_like(y_pred), torch.zeros_like(y_pred))
        true.extend(label)
        pred.extend(predict)

    true = np.array(torch.tensor(true, device='cpu'))
    pred = np.array(torch.tensor(pred, device='cpu'))
    y_score = np.array(torch.tensor(y_score, device='cpu', requires_grad=False))

    if len(true) == 0:
        return 0, 0, 0, 0, 0, 0, 0

    acc = accuracy_score(true, pred)
    recall_scores = recall_score(true, pred)
    f1_scores = f1_score(true, pred)
    precision_scores = precision_score(true, pred)
    mcc = matthews_corrcoef(true, pred)
    auc = roc_auc_score(true, y_score)

    return acc, test_loss, recall_scores, f1_scores, precision_scores, auc, mcc

dataset = MyDataset()
nums_epoches = 30
k = 5
splits = KFold(n_splits=k, shuffle=True, random_state=42)
foldperf = {}
for fold, (train_idx, test_idx) in enumerate(splits.split(np.arange(len(dataset)))):
    print(f'Fold {fold + 1}')

    train_sampler = SubsetRandomSampler(train_idx)
    test_sampler = SubsetRandomSampler(test_idx)

    train_loader = DataLoader(dataset, batch_size=1, sampler=train_sampler, drop_last=True, collate_fn=collate,
                              num_workers=16, pin_memory=True)
    test_loader = DataLoader(dataset, batch_size=1, sampler=test_sampler, drop_last=True, collate_fn=collate,
                             num_workers=16, pin_memory=True)

    with open(f'train_samples_fold_{fold + 1}.txt', 'w') as train_file:
        for idx in train_idx:
            train_file.write(f"{idx}\n")

    with open(f'test_samples_fold_{fold + 1}.txt', 'w') as test_file:
        for idx in test_idx:
            test_file.write(f"{idx}\n")

    model = EGATPPI().type(torch.FloatTensor)
    model = model.to(device)
    criterion = torch.nn.BCELoss()
    criterion = criterion.to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=0.001, weight_decay=1e-4)
    scheduler = torch.optim.lr_scheduler.ExponentialLR(optimizer, gamma=0.95)
    history = {'train_loss': [], 'test_loss': [], 'train_acc': [], 'test_acc': [],
               'train_recall_scores': [], 'test_recall_scores': [], 'train_f1_scores': [], 'test_f1_scores': [],
               'train_precision_scores': [], 'test_precision_scores': [],
               'train_auc': [], 'train_mcc': [],
               'test_auc': [], 'test_mcc': []}

    for epoch in range(nums_epoches):
        train_acc, train_loss, train_recall_scores, train_f1_scores, train_precision_scores, train_auc, train_mcc = train_epoch(
            model, train_loader, criterion, optimizer)
        test_acc, test_loss, test_recall_scores, test_f1_scores, test_precision_scores, test_auc, test_mcc = Val_epoch(
            model, test_loader, criterion)

        train_loader_len = len(train_loader.sampler) if len(train_loader.sampler) > 0 else 1
        test_loader_len = len(test_loader.sampler) if len(test_loader.sampler) > 0 else 1

        train_loss = train_loss / train_loader_len
        train_acc = train_acc * 100
        test_loss = test_loss / test_loader_len
        test_acc = test_acc * 100
        scheduler.step()
        print(
            "Epoch:{}/{} AVG Training Loss:{:.3f} AVG Test Loss:{:.3f} AVG Training Acc {:.2f} % AVG Test Acc {:.2f} % Training Pre {:.4f} Test pre {:.4f} Training AUC {:.4f} Test AUC {:.4f} Training MCC {:.4f} Test MCC {:.4f} Training Recall {:.4f} Training F1 score {:.4f} Test Recall {:.4f} Test F1 score {:.4f}".format(
                epoch + 1,
                nums_epoches,
                train_loss,
                test_loss,
                train_acc,
                test_acc,
                train_precision_scores,
                test_precision_scores,
                train_auc,
                test_auc,
                train_mcc,
                test_mcc,
                train_recall_scores,
                train_f1_scores,
                test_recall_scores,
                test_f1_scores))
        history['train_loss'].append(train_loss)
        history['test_loss'].append(test_loss)
        history['train_acc'].append(train_acc)
        history['test_acc'].append(test_acc)
        history['train_recall_scores'].append(train_recall_scores)
        history['train_f1_scores'].append(train_f1_scores)
        history['train_precision_scores'].append(train_precision_scores)
        history['test_recall_scores'].append(test_recall_scores)
        history['test_f1_scores'].append(test_f1_scores)
        history['test_precision_scores'].append(test_precision_scores)
        history['train_auc'].append(train_auc)
        history['train_mcc'].append(train_mcc)
        history['test_auc'].append(test_auc)
        history['test_mcc'].append(test_mcc)
        torch.save(model.state_dict(), f'fold_{fold + 1}_epoch_{epoch + 1}.pt')
    foldperf['fold{}'.format(fold + 1)] = history

with open('foldperfGNN5fold.pkl', 'wb') as fo:
    pickle.dump(foldperf, fo)
    fo.close()