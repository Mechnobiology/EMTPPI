import os
import numpy as np
from Bio import PDB

def calculate_normal_vector(coords):
    vec1 = coords[1] - coords[0]
    vec2 = coords[2] - coords[0]
    normal = np.cross(vec1, vec2)
    return normal / np.linalg.norm(normal)

def calculate_angle(vec1, vec2):
    cosine = np.clip(np.dot(vec1, vec2), -1.0, 1.0)

    angle = np.arccos(cosine) * 180.0 / np.pi

    return angle / 180.0

def calculate_ring_angle(file_path):
    parser = PDB.PDBParser(QUIET=True)
    structure = parser.get_structure('pid', file_path)

    residues = []
    coordinates = {}

    for model in structure:
        for chain in model:
            for residue in chain:
                residues.append(residue)
                coords = []
                atom_names = []
                if residue.get_resname() in ['PHE', 'TYR']:
                    atom_names = ['CG', 'CE1', 'CE2']
                elif residue.get_resname() == 'TRP':
                    atom_names = ['CG', 'CE3', 'CZ2']
                elif residue.get_resname() == 'HIS':
                    atom_names = ['CG', 'CD2', 'CE1']

                for atom in residue.get_atoms():
                    if atom.get_name() in atom_names:
                        coords.append(atom.get_coord())

                if len(coords) == 3:
                    coordinates[residue.get_id()] = np.array(coords)

    n = len(residues)
    angle_matrix = np.zeros((n, n))

    for i in range(n):
        if residues[i].get_id() in coordinates:
            normal_i = calculate_normal_vector(coordinates[residues[i].get_id()])
            for j in range(n):
                if residues[j].get_id() in coordinates:
                    normal_j = calculate_normal_vector(coordinates[residues[j].get_id()])
                    angle_matrix[i, j] = calculate_angle(normal_i, normal_j)

    return angle_matrix

def process_pdb_files(input_dir, output_dir):
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    for filename in os.listdir(input_dir):
        if filename.endswith('.pdb'):
            pdb_file_path = os.path.join(input_dir, filename)
            angle_matrix = calculate_ring_angle(pdb_file_path)
            output_file_path = os.path.join(output_dir, f"{os.path.splitext(filename)[0]}.npz")
            np.savez(output_file_path, ring_angle=angle_matrix)

input_folder = ''
output_folder = ''
process_pdb_files(input_folder, output_folder)