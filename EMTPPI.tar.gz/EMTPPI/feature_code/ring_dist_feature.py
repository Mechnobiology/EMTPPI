import os
import numpy as np
from Bio import PDB

def calculate_centroid(coords):
    return np.mean(coords, axis=0)

def calculate_ring_dist(file_path):
    parser = PDB.PDBParser(QUIET=True)
    structure = parser.get_structure('pid', file_path)

    all_residues = []
    rings = []
    ring_indices = []

    for model in structure:
        for chain in model:
            for index, residue in enumerate(chain):
                all_residues.append(residue)
                if residue.get_resname() in ['PHE', 'TYR', 'TRP', 'HIS']:
                    coords = []
                    if residue.get_resname() in ['PHE', 'TYR']:
                        atom_names = ['CG', 'CE1', 'CE2']
                    elif residue.get_resname() in ['TRP']:
                        atom_names = ['CG', 'CE3', 'CZ2']
                    elif residue.get_resname() in ['HIS']:
                        atom_names = ['CG', 'CD2', 'CE1']

                    for atom in residue.get_atoms():
                        if atom.get_name() in atom_names:
                            coords.append(atom.get_coord())

                    if len(coords) == 3:
                        rings.append(np.array(coords))
                        ring_indices.append(index)

    centroids = [calculate_centroid(ring) for ring in rings]
    n_residues = len(all_residues)
    sij_matrix = np.zeros((n_residues, n_residues))

    d0 = 4

    for i, ring_index_i in enumerate(ring_indices):
        for j, ring_index_j in enumerate(ring_indices):
            if i != j:
                distmin = np.linalg.norm(centroids[i] - centroids[j])
                sij = 2 * d0 / (d0 + max(d0, distmin))
                sij_matrix[ring_index_i, ring_index_j] = sij
                sij_matrix[ring_index_j, ring_index_i] = sij

    return sij_matrix

def process_pdb_files(input_dir, output_dir):
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    for filename in os.listdir(input_dir):
        if filename.endswith('.pdb'):
            pdb_file_path = os.path.join(input_dir, filename)
            ring_dist_matrix = calculate_ring_dist(pdb_file_path)
            output_file_path = os.path.join(output_dir, f"{os.path.splitext(filename)[0]}.npz")
            np.savez(output_file_path, ring_dist=ring_dist_matrix)

input_folder = ''
output_folder = ''
process_pdb_files(input_folder, output_folder)