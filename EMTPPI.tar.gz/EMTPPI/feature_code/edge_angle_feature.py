from Bio.PDB.PDBParser import PDBParser
from math import sqrt
import numpy as np
from biopandas.pdb import PandasPdb
import os
from concurrent.futures import ProcessPoolExecutor, as_completed
import multiprocessing

def calc_dist(p1, p2):
    dx = p1[0] - p2[0]
    dy = p1[1] - p2[1]
    dz = p1[2] - p2[2]
    return sqrt(dx**2 + dy**2 + dz**2)

def residue_relative_angle(res1, res2, THIRD_ATOM):
    if 'CA' in res1 and THIRD_ATOM in res1 and 'C' in res1:
        v1 = res1['CA'].get_vector().get_array()
        v2 = res1[THIRD_ATOM].get_vector().get_array()
        v3 = res1['C'].get_vector().get_array()
        normal1 = np.cross((v2 - v1), (v3 - v1))
    else:
        if len(res1) == 1:
            normal1 = list(res1.child_dict.values())[0].get_vector().get_array()
        else:
            raise ValueError("Unexpected residue format in res1")
    normal1 = normal1 / np.linalg.norm(normal1)

    if 'CA' in res2 and THIRD_ATOM in res2 and 'C' in res2:
        v1 = res2['CA'].get_vector().get_array()
        v2 = res2[THIRD_ATOM].get_vector().get_array()
        v3 = res2['C'].get_vector().get_array()
        normal2 = np.cross((v2 - v1), (v3 - v1))
    else:
        if len(res2) == 1:
            normal2 = list(res2.child_dict.values())[0].get_vector().get_array()
        else:
            raise ValueError("Unexpected residue format in res2")
    normal2 = normal2 / np.linalg.norm(normal2)

    cosine = np.clip(np.dot(normal1, normal2), -1.0, 1.0)
    angle = np.arccos(cosine) * 180 / np.pi
    return angle / 180.0

def distance_map(path, pdbid):
    try:
        p = PDBParser(QUIET=True)
        in_file = os.path.join(path, pdbid + ".pdb")
        structure = p.get_structure(pdbid, in_file)
        model = structure[0]
        chain = model.get_list()[0]

        exposed_id_list = [res.get_id()[1] for res in chain if res.id[0] == ' ']

        ppdb = PandasPdb().read_pdb(in_file)
        number = len(exposed_id_list)
        answer = np.ones((number, number), np.float64)
        angle_mat = np.zeros((number, number), np.float64)

        for i in range(number):
            coord1 = list(chain[exposed_id_list[i]]['CA'].get_vector())
            for j in range(i + 1, number):
                angle = residue_relative_angle(chain[exposed_id_list[i]], chain[exposed_id_list[j]], THIRD_ATOM='N')
                angle_mat[i, j] = angle
                angle_mat[j, i] = angle
                coord2 = list(chain[exposed_id_list[j]]['CA'].get_vector())
                dist = calc_dist(coord1, coord2)

                if dist > 30:
                    answer[i, j] = 0
                    answer[j, i] = 0
                else:
                    atom_df = ppdb.df['ATOM']
                    filtered_df = atom_df.loc[atom_df['element_symbol'] != 'H']
                    p1 = filtered_df[filtered_df['residue_number'] == exposed_id_list[i]]
                    p2 = filtered_df[filtered_df['residue_number'] == exposed_id_list[j]]
                    p1_coord = [row[11:14].tolist() for _, row in p1.iterrows()]
                    p2_coord = [row[11:14].tolist() for _, row in p2.iterrows()]

                    distmin = 30
                    for m in range(len(p1_coord)):
                        for n in range(len(p2_coord)):
                            atom_dist = calc_dist(p1_coord[m], p2_coord[n])
                            if atom_dist < distmin:
                                distmin = atom_dist

                    if distmin > 8.0:
                        answer[i, j] = 0
                        answer[j, i] = 0
                    else:
                        d0 = 4
                        sij = 2*d0/(d0+max(d0, distmin))
                        answer[i, j] = sij
                        answer[j, i] = sij

        for i in range(number):
            answer[i, i] = 0

        return answer, angle_mat

    except Exception as e:
        print(f"error {pdbid}: {e}")
        return None, None

input_folder = ''
output_folder = ''

if not os.path.exists(output_folder):
    os.makedirs(output_folder)

pdb_files = [f for f in os.listdir(input_folder) if f.endswith('.pdb')]

def process_pdb_files(pdb_file):
    name = os.path.splitext(pdb_file)[0]
    print(f"processing {name}")
    answer, angle_mat = distance_map(input_folder, name)
    if answer is not None and angle_mat is not None:
        np.savez(os.path.join(output_folder, name + '.npz'), contact=answer, angle=angle_mat)
        print(f"Saved {name}")
    else:
        print(f"Failed {name}")
    return name, answer, angle_mat

num_cpus = multiprocessing.cpu_count()
with ProcessPoolExecutor(max_workers=num_cpus) as executor:
    futures = {executor.submit(process_pdb_files, pdb_file): pdb_file for pdb_file in pdb_files}
    for future in as_completed(futures):
        pass
