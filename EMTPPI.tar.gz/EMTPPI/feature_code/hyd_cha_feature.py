import os
from Bio.PDB.PDBParser import PDBParser
from Bio.SeqUtils import seq1
import numpy as np
from concurrent.futures import ProcessPoolExecutor, as_completed
import multiprocessing

dict_hydrophobe = {'R':-7.5, 'K':-4.6, 'D':-3.0, 'Q':-2.9, 'N':-2.7, 'E':-2.6, 'H':-1.7, 'S':-1.1, 'T':-0.8, 
                   'P':-0.3, 'Y':0.1, 'C':0.2, 'G':0.7, 'A':1.0, 'M':1.1, 'W':1.5, 'L':2.2, 'V':2.3, 'F':2.5, 'I':3.1}

dict_charge = {'R':10.8, 'K':9.7, 'D':2.8, 'Q':5.7, 'N':5.4, 'E':3.2, 'H':7.6, 'S':5.7, 'T':5.9, 
               'P':6.5, 'Y':5.7, 'C':5.1, 'G':6.0, 'A':6.0, 'M':5.7, 'W':6.0, 'L':6.0, 'V':6.0, 'F':5.5, 'I':5.9}

def mapping_matrix(matrix):
    return matrix / 20

def cal_hyd_cha_map(path, pdbid):
    p = PDBParser(QUIET=True)
    in_file = os.path.join(path, pdbid + '.pdb')
    structure = p.get_structure(pdbid, in_file)
    model = structure[0]
    chain = model.get_list()
    chain_id1 = chain[0]

    residues_chain1 = [seq1(residue.get_resname()) for residue in chain_id1]
    number = len(residues_chain1)

    hyd_map = np.zeros((number, number), np.float64)
    cha_map = np.zeros((number, number), np.float64)

    # hydrophobe map(HCI)
    for i in range(number):
        for j in range(number):
            hyd_map[i, j] = 20 - abs((dict_hydrophobe[residues_chain1[i]] - dict_hydrophobe[residues_chain1[j]]) * 19 / 10.6)
    hyd_map = mapping_matrix(hyd_map)

    # charge map(CCI)
    for i in range(number):
        for j in range(number):
            cha_map[i, j] = 11 - (dict_charge[residues_chain1[i]] - 7) * (dict_charge[residues_chain1[j]] - 7) * 19 / 33.8
    cha_map = mapping_matrix(cha_map)

    return hyd_map, cha_map

def process_single_pdb(pdb_file, pdb_folder, output_folder):
    protein_id = pdb_file[:-4]
    try:
        hyd_map, cha_map = cal_hyd_cha_map(pdb_folder, protein_id)
        output_file = os.path.join(output_folder, protein_id + '.npz')
        np.savez(output_file, hyd=hyd_map, cha=cha_map)
        return True
    except Exception as e:
        print(f"Failed: {protein_id}: {e}")
        return False

def process_pdb_files(pdb_folder, output_folder):
    os.makedirs(output_folder, exist_ok=True)
    pdb_files = [f for f in os.listdir(pdb_folder) if f.endswith('.pdb')]
    num_cpus = multiprocessing.cpu_count()
    failed_files = []

    with ProcessPoolExecutor(max_workers=num_cpus) as executor:
        futures = {executor.submit(process_single_pdb, pdb_file, pdb_folder, output_folder): pdb_file for pdb_file in pdb_files}
        for future in as_completed(futures):
            pdb_file = futures[future]
            try:
                success = future.result()
                if not success:
                    failed_files.append(pdb_file)
            except Exception as e:
                print(f"Failed: {pdb_file}: {e}")
                failed_files.append(pdb_file)

    if failed_files:
        print("\nThe following files failed to process:")
        for f in failed_files:
            print(f)

pdb_folder = ''
output_folder = ''
process_pdb_files(pdb_folder, output_folder)
