import numpy as np
from Bio.PDB.PDBParser import PDBParser
from Bio.SeqUtils import seq1
import os

def dic_normalize(dic):
    if not dic:
        return dic
    max_value = dic[max(dic, key=dic.get)]
    min_value = dic[min(dic, key=dic.get)]
    
    interval = float(max_value) - float(min_value)
    if interval == 0:
        for key in dic.keys():
            dic[key] = 0.0
    else:
        for key in dic.keys():
            dic[key] = (dic[key] - min_value) / interval
    
    return dic

pro_res_aromatic_table = ['F', 'W', 'Y']
res_hydrophobe_table = {'R': -7.5, 'K': -4.6, 'D': -3.0, 'Q': -2.9, 'N': -2.7, 'E': -2.6, 'H': -1.7, 'S': -1.1, 'T': -0.8, 'P': -0.3, 'Y': 0.1, 'C': 0.2, 'G': 0.7, 'A': 1.0, 'M': 1.1, 'W': 1.5, 'L': 2.2, 'V': 2.3, 'F': 2.5, 'I': 3.1}
res_charge_table = {'R': 10.8, 'K': 9.7, 'D': 2.8, 'Q': 5.7, 'N': 5.4, 'E': 3.2, 'H': 7.6, 'S': 5.7, 'T': 5.9, 'P': 6.5, 'Y': 5.7, 'C': 5.1, 'G': 6.0, 'A': 6.0, 'M': 5.7, 'W': 6.0, 'L': 6.0, 'V': 6.0, 'F': 5.5, 'I': 5.9}
res_pka_table = {'A': 2.34, 'C': 1.96, 'D': 1.88, 'E': 2.19, 'F': 1.83, 'G': 2.34, 'H': 1.82, 'I': 2.36, 'K': 2.18, 'L': 2.36, 'M': 2.28, 'N': 2.02, 'P': 1.99, 'Q': 2.17, 'R': 2.17, 'S': 2.21, 'T': 2.11, 'V': 2.32, 'W': 2.38, 'Y': 2.20}
res_pkb_table = {'A': 9.69, 'C': 10.28, 'D': 9.60, 'E': 9.67, 'F': 9.13, 'G': 9.60, 'H': 9.17, 'I': 9.68, 'K': 8.95, 'L': 9.60, 'M': 9.21, 'N': 8.80, 'P': 10.96, 'Q': 9.13, 'R': 9.04, 'S': 9.15, 'T': 9.62, 'V': 9.62, 'W': 9.39, 'Y': 9.11}
res_pkx_table = {'A': 0.00, 'C': 8.18, 'D': 3.65, 'E': 4.25, 'F': 0.00, 'G': 0.00, 'H': 6.00, 'I': 0.00, 'K': 10.53, 'L': 0.00, 'M': 0.00, 'N': 0.00, 'P': 0.00, 'Q': 0.00, 'R': 12.48, 'S': 0.00, 'T': 0.00, 'V': 0.00, 'W': 0.00, 'Y': 10.07}
res_side_chain_length_table = {'A': 1.51, 'C': 2.83, 'D': 3.74, 'E': 4.97, 'F': 5.10, 'G': 0.00, 'H': 4.64, 'I': 3.91, 'K': 6.37, 'L': 3.90, 'M': 5.46, 'N': 3.68, 'P': 2.40, 'Q': 4.93, 'R': 7.40, 'S': 2.41, 'T': 2.54, 'V': 2.55, 'W': 6.64, 'Y': 6.43}
res_polar_table = {'A': 0.00, 'C': 1.00, 'D': 2.00, 'E': 2.00, 'F': 0.00, 'G': 1.00, 'H': 3.00, 'I': 0.00, 'K': 3.00, 'L': 0.00, 'M': 0.00, 'N': 1.00, 'P': 0.00, 'Q': 1.00, 'R': 3.00, 'S': 1.00, 'T': 1.00, 'V': 0.00, 'W': 0.00, 'Y': 1.00}
res_hba_table = {'A': 2.00, 'C': 3.00, 'D': 3.00, 'E': 3.00, 'F': 2.00, 'G': 2.00, 'H': 3.00, 'I': 2.00, 'K': 3.00, 'L': 2.00, 'M': 3.00, 'N': 3.00, 'P': 2.00, 'Q': 3.00, 'R': 3.00, 'S': 3.00, 'T': 3.00, 'V': 2.00, 'W': 2.00, 'Y': 3.00}
res_hbd_table = {'A': 2.00, 'C': 3.00, 'D': 3.00, 'E': 3.00, 'F': 2.00, 'G': 2.00, 'H': 3.00, 'I': 2.00, 'K': 3.00, 'L': 2.00, 'M': 2.00, 'N': 3.00, 'P': 2.00, 'Q': 3.00, 'R': 4.00, 'S': 3.00, 'T': 3.00, 'V': 2.00, 'W': 3.00, 'Y': 3.00}
res_owpc_table = {'A': -0.58, 'C': 0.67, 'D': -1.13, 'E': -0.47, 'F': 0.64, 'G': -0.97, 'H': -0.64, 'I': 0.44, 'K': -0.47, 'L': 0.44, 'M': 0.15, 'N': -1.73, 'P': -0.18, 'Q': -1.34, 'R': -1.55, 'S': -1.61, 'T': -1.22, 'V': 0.05, 'W': 1.12, 'Y': 0.35}
res_nar_table = {'A': 0.00, 'C': 0.00, 'D': 0.00, 'E': 0.00, 'F': 1.00, 'G': 0.00, 'H': 1.00, 'I': 0.00, 'K': 0.00, 'L': 0.00, 'M': 0.00, 'N': 0.00, 'P': 0.00, 'Q': 0.00, 'R': 0.00, 'S': 0.00, 'T': 0.00, 'V': 0.00, 'W': 2.00, 'Y': 1.00}

res_hydrophobe_table = dic_normalize(res_hydrophobe_table)
res_charge_table = dic_normalize(res_charge_table)
res_pka_table = dic_normalize(res_pka_table)
res_pkb_table = dic_normalize(res_pkb_table)
res_pkx_table = dic_normalize(res_pkx_table)
res_side_chain_length_table = dic_normalize(res_side_chain_length_table)
res_polar_table = dic_normalize(res_polar_table)
res_hba_table = dic_normalize(res_hba_table)
res_hbd_table = dic_normalize(res_hbd_table)
res_owpc_table = dic_normalize(res_owpc_table)
res_nar_table = dic_normalize(res_nar_table)

def calculate_TPSA(pdb_file):
    p = PDBParser(QUIET=True)
    structure = p.get_structure("pid", pdb_file)
    res_tpsa = {}
    for chain in structure.get_chains():
        for residue in chain.get_residues():
            residue_TPSA = 0.0
            for atom in residue.get_atoms():
                element_symbol = atom.element
                if element_symbol in ['O', 'N', 'H']:
                    residue_TPSA += atom.bfactor
            residue_name = seq1(residue.resname)
            res_tpsa[residue_name] = residue_TPSA
    res_tpsa = {residue_name: round(TPSA, 2) for residue_name, TPSA in res_tpsa.items()}
    return res_tpsa

def residue_features(residue, res_tpsa_table):
    res_property1 = [1 if residue in pro_res_aromatic_table else 0]
    res_property2 = [res_hydrophobe_table[residue], res_charge_table[residue], res_pka_table[residue], res_pkb_table[residue], res_pkx_table[residue],
                     res_side_chain_length_table[residue], res_polar_table[residue], res_hba_table[residue],
                     res_hbd_table[residue], res_owpc_table[residue], res_nar_table[residue], res_tpsa_table[residue]]
    return np.array(res_property1 + res_property2)

def calculate_features(pdb_file):
    p = PDBParser(QUIET=True)
    structure = p.get_structure("pid", pdb_file)
    residue_features_list = []

    try:
        res_tpsa_table = calculate_TPSA(pdb_file)
        if not res_tpsa_table:
            return None
        res_tpsa_table = dic_normalize(res_tpsa_table)

        for chain in structure.get_chains():
            for residue in chain.get_residues():
                residue_name = seq1(residue.resname)

                # 13 dim
                base_features = residue_features(residue_name, res_tpsa_table)

                # new surface and RSA feature
                surface_feature = 0.0
                try:
                    alpha_carbon = residue['CA']
                    rsa_feature = alpha_carbon.get_occupancy()
                    if rsa_feature > 0:
                        surface_feature = 1.0
                except KeyError:
                    print(f"Warning: Residue {residue.get_id()} in {pdb_file} has no 'CA' atom. Skipping file.")
                    raise KeyError(f"Residue {residue.get_id()} has no 'CA' atom.")
                
                full_features = np.concatenate((base_features, [rsa_feature, surface_feature]))
                
                residue_features_list.append(full_features)

        feature_matrix = np.array(residue_features_list)
        return feature_matrix

    except KeyError as e:
        print(f"Error for {pdb_file}: {e}. Skipping file.")
        return None

def process_pdb_files(pdb_folder, output_folder):
    os.makedirs(output_folder, exist_ok=True)

    pdb_files = [f for f in os.listdir(pdb_folder) if f.endswith(".pdb")]
    skipped_files = []

    for pdb_filename in pdb_files:
        protein_id = os.path.splitext(pdb_filename)[0]
        pdb_file = os.path.join(pdb_folder, pdb_filename)

        print(f"Processing {pdb_filename}...")

        try:
            feature_matrix = calculate_features(pdb_file)

            if feature_matrix is None or feature_matrix.size == 0:
                print(f"Skipped {pdb_filename}: no valid residues")
                skipped_files.append(pdb_filename)
                continue

            output_file = os.path.join(output_folder, f"{protein_id}.npz")
            np.savez(output_file, feature=feature_matrix)
            print(f"Saved features {feature_matrix.shape} for {pdb_filename}")

        except Exception as e:
            print(f"Error processing {pdb_filename}: {e}")
            skipped_files.append(pdb_filename)

    print("\nSummary:")
    if skipped_files:
        for f in skipped_files:
            print(f)
    else:
        print("All files processed successfully.")

pdb_folder = ''
output_folder = ''

process_pdb_files(pdb_folder, output_folder)