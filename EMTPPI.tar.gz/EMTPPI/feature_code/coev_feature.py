import os
import numpy as np
import scipy.linalg as la
import numpy.linalg as na
import multiprocessing
from concurrent.futures import ProcessPoolExecutor, as_completed

aadic = {
    'A': 1, 'B': 0, 'C': 2, 'D': 3, 'E': 4,
    'F': 5, 'G': 6, 'H': 7, 'I': 8, 'J': 0,
    'K': 9, 'L': 10, 'M': 11, 'N': 12, 'O': 0,
    'P': 13, 'Q': 14, 'R': 15, 'S': 16, 'T': 17, 'U': 0,
    'V': 18, 'W': 19, 'X': 0, 'Y': 20, 'Z': 0,
    '-': 0, '*': 0
}

def read_msa(file_path):
    lines = open(file_path).readlines()
    lines = [line.strip() for line in lines]
    n = len(lines)
    d = len(lines[0])
    msa = np.zeros([n, d], dtype=int)
    for i in range(n):
        aline = lines[i]
        for j in range(d):
            msa[i, j] = aadic[aline[j]]
    return msa

def cal_seq_iden(seq1, seq2):
    matches = sum(a == b for a, b in zip(seq1, seq2))
    identity = matches / len(seq1) * 100
    return identity

def cal_seq_weight(query_seq, other_sequences, threshold=80):
    identity_count = 0
    for other_sequence in other_sequences:
        identity = cal_seq_iden(query_seq, other_sequence)
        if identity > threshold:
            identity_count += 1
    weight = 1 / (identity_count + 1)
    return weight

def cal_weights(msa_file, threshold=80):
    lines = open(msa_file, "r").readlines()
    lines = [line.strip() for line in lines]
    weights = []
    for i, query_seq in enumerate(lines):
        query_seq = query_seq.strip()
        other_sequences = [seq.strip() for j, seq in enumerate(lines) if i != j]
        weight = cal_seq_weight(query_seq, other_sequences, threshold)
        weights.append(weight)
    return weights

def cal_large_matrix1(msa, weight):
    ALPHA = 21
    pseudoc = 1
    M = msa.shape[0]
    N = msa.shape[1]
    pab = np.zeros((ALPHA, ALPHA))
    pa = np.zeros((N, ALPHA))
    cov = np.zeros([N * ALPHA, N * ALPHA])

    for i in range(N):
        for aa in range(ALPHA):
            pa[i, aa] = pseudoc

        neff = 0.0
        for k in range(M):
            pa[i, msa[k, i]] += weight[k]
            neff += weight[k]

        for aa in range(ALPHA):
            pa[i, aa] /= pseudoc * ALPHA * 1.0 + neff

    for i in range(N):
        for j in range(i, N):
            for a in range(ALPHA):
                for b in range(ALPHA):
                    if i == j:
                        if a == b:
                            pab[a, b] = pa[i, a]
                        else:
                            pab[a, b] = 0.0
                    else:
                        pab[a, b] = pseudoc * 1.0 / ALPHA

            if i != j:
                neff2 = 0
                for k in range(M):
                    a = msa[k, i]
                    b = msa[k, j]
                    tmp = weight[k]
                    pab[a, b] += tmp
                    neff2 += tmp

                for a in range(ALPHA):
                    for b in range(ALPHA):
                        pab[a, b] /= pseudoc * ALPHA * 1.0 + neff2

            for a in range(ALPHA):
                for b in range(ALPHA):
                    if i != j or a == b:
                        if pab[a][b] > 0.0:
                            cov[i * 21 + a][j * 21 + b] = pab[a][b] - pa[i][a] * pa[j][b]
                            cov[j * 21 + b][i * 21 + a] = cov[i * 21 + a][j * 21 + b]

    return cov

def ROPE(S, rho):
    p = S.shape[0]
    try:
        LM = na.eigh(S)
    except:
        LM = la.eigh(S)
    L = LM[0]
    M = LM[1]
    for i in range(len(L)):
        if L[i] < 0:
            L[i] = 0
    lamda = 2.0 / (L + np.sqrt(np.power(L, 2) + 8 * rho))
    indexlamda = np.argsort(-lamda)
    lamda = np.diag(-np.sort(-lamda)[:p])
    hattheta = np.dot(M[:, indexlamda], lamda)
    hattheta = np.dot(hattheta, M[:, indexlamda].transpose())
    return hattheta

def blockshaped(arr, dim=21):
    p = arr.shape[0] // dim
    re = np.zeros((p, p, dim, dim))
    for i in range(p):
        for j in range(p):
            re[i, j] = arr[i * dim:i * dim + dim, j * dim:j * dim + dim]
    return re

def computepre(msafile):
    msa = read_msa(msafile)
    weights = cal_weights(msafile)
    cov = cal_large_matrix1(msa, weights)
    rho2 = np.exp((np.arange(80) - 60) / 5.0)[30]
    pre = ROPE(cov, rho2)
    return pre

def compute_Frobenius_norm_no_gaps(msafile, dim=21, pseudoc=1.0):
    msa = read_msa(msafile)
    weights = cal_weights(msafile)
    M, L = msa.shape
    ALPHA = dim
    neff = sum(weights)

    pa = np.zeros((L, ALPHA))
    for i in range(L):
        pa[i] += pseudoc
        for k in range(M):
            aa = msa[k, i]
            pa[i, aa] += weights[k]
        pa[i] /= (pseudoc * ALPHA + neff)

    Frobenius_norm_matrix = np.zeros((L, L))

    for i in range(L):
        for j in range(i, L):
            pab = np.ones((ALPHA, ALPHA)) * (pseudoc / ALPHA)
            for k in range(M):
                a = msa[k, i]
                b = msa[k, j]
                pab[a, b] += weights[k]
            pab /= (pseudoc * ALPHA + neff)

            cov_block = pab - np.outer(pa[i], pa[j])

            non_gap_block = cov_block[1:, 1:]
            frob = np.sqrt(np.sum(non_gap_block**2))
            Frobenius_norm_matrix[i, j] = frob
            Frobenius_norm_matrix[j, i] = frob

    return Frobenius_norm_matrix

def process_single_msa(msafile, output_folder):
    filename = os.path.basename(msafile)
    output_file = os.path.join(output_folder, filename.replace(".aln", ".npz"))
    try:
        pre_matrix = compute_Frobenius_norm_no_gaps(msafile, dim=21)
        np.savez(output_file, coev=pre_matrix)
        return True
    except Exception as e:
        print(f"Failed: {filename}: {e}")
        return False

def process_pdb_files(input_folder, output_folder):
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    msafiles = [os.path.join(input_folder, f) for f in os.listdir(input_folder) if f.endswith(".aln")]

    num_cpus = multiprocessing.cpu_count()
    failed_files = []

    with ProcessPoolExecutor(max_workers=num_cpus) as executor:
        futures = {executor.submit(process_single_msa, msafile, output_folder): msafile for msafile in msafiles}
        for future in as_completed(futures):
            msafile = futures[future]
            try:
                success = future.result()
                if not success:
                    failed_files.append(os.path.basename(msafile))
            except Exception as e:
                print(f"Failed: {os.path.basename(msafile)}: {e}")
                failed_files.append(os.path.basename(msafile))

    if failed_files:
        print("\nThe following files failed to process:")
        for f in failed_files:
            print(f)

input_folder = ''
output_folder = ''
process_pdb_files(input_folder, output_folder)