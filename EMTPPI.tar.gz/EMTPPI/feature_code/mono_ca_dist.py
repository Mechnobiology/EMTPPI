from Bio import PDB
import numpy as np
import os

def calculate_ca_distance(pdb_file):
    parser = PDB.PDBParser(QUIET=True)
    structure = parser.get_structure('pid', pdb_file)

    residues = list(structure.get_residues())
    num_residues = len(residues)
    ca_coord = []

    filename = os.path.basename(pdb_file)

    for residue in residues:
        if 'CA' not in residue:
            print(f"Warning: No CA atom in residue {residue.get_id()[1]} in {filename}")
        else:
            ca_coord.append(residue['CA'].coord)

    if len(ca_coord) == 0:
        print(f"Warning: No CA atoms found in {filename}")
        return None

    d0 = 4
    sij_matrix = np.zeros((num_residues, num_residues))

    for i in range(len(ca_coord)):
        for j in range(i + 1, len(ca_coord)):
            ca_distance = np.linalg.norm(ca_coord[i] - ca_coord[j])
            sij = 2 * d0 / (d0 + max(d0, ca_distance))
            sij_matrix[i, j] = sij
            sij_matrix[j, i] = sij

    return sij_matrix

def process_pdb_files(input_folder, output_folder):
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    for filename in os.listdir(input_folder):
        if filename.endswith('.pdb'):
            pdb_file = os.path.join(input_folder, filename)
            sij_matrix = calculate_ca_distance(pdb_file)
            output_file = os.path.join(output_folder, f'{filename[:-4]}.npz')
            np.savez(output_file, ca_dist=sij_matrix)

input_folder = ''
output_folder = ''
process_pdb_files(input_folder, output_folder)